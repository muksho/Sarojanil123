<footer>
	<div class="container-fluid">
	<div class="row">
	  <div class="col-sm-4">
	  	<h2 class="title-anchor">SAROJANIL</h2>
	  	<p>Sarojanil Technology is a web development company has hands on experience in application development, Ecommerce development and website designing in Dhanbad. Sarojanil Technology offers web designing services one step higher than your expectation. We have hosted, developed and launched hundreds of websites for various businesses with appealing web designs. Each step of our web design, website development is towards reaching the right audience for your business.</p>
	  </div>
	  <div class="col-sm-4"><center>
	  	<h2 class="title-anchor">Contact</h2>
	  	<ul style="list-style-type:none">
	  		<li><a href="https://www.google.com/maps/place/Sarojanil+Technology+Private+Limited/@23.8182896,86.4650388,16.73z/data=!4m5!3m4!1s0x0:0x69eee711e8625866!8m2!3d23.81775!4d86.466615?hl=en-US" target="_blank"><img src="images/address.png"><br> 2nd Floor, Raj Complex,
												Beside NEXA Showroom,
												Main Road Kolakusma,
												Saraidhela, Dhanbaad
												Jharkhand - 828127
												</a>
			</li><br>
	  		<li><img src="images/call.png">  +91-7004425367</li><br>
	  		<li><img src="images/mail.png">   sales@sarojaniltechnology.com</li><br>
	  		<li style="padding: 5px;">
	  			<a href="#"><img src="images/facebook.png"></a>
	  			<a href="#"><img src="images/twitter.png"></a>
	  			<a href="#"><img src="images/google.png"></a>
	  			<a href="#"><img src="images/linked-in.png"></a>
	  		</li>
	  	</ul>
	  </center>
	  </div>
	  <div class="col-sm-4">
	  	.col-sm-4
	  </div>
	</div>
	<hr style="height:2px; background-color: red; border:none;color:#ec7201">
	</div>
	         <div class="footer" style="text-align: center;">
	            
	                 © COPYRIGHT 2017. <span style="color: #246fc1;">"SAROJANIL TECHNOLOGY PRIVATE LIMITED"</span>. ALL RIGHTS RESERVED.
	             
	        </div>
	        <br>
	</div>
</footer>
<!--/.Footer--> 
  </body>
</html>