<?php $pageid=4;?>
<!DOCTYPE html>

<html lang="en">
<!-- Starting of head -->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>FACE RECOGNISATION DEVICE</title>
	    <meta name="Description" content="IT service provider in dhanbad" />
	    <meta name="Keywords" content="Dhanbad" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/style-index.css">
		
		<?php include 'header.php';?>
			<img src="images/face_recognition_device.jpg" class="img-responsive" style="width: 100%;">
			<div class="container-fluid">
			<div style="padding: 5px;"></div>
			<div>
				<p>Face Recognition Device is one of the emerging technology in the field of attendance and security. Basically it is the advancement of Biometric Attendance which is used world wide.</p>

				<p>Face Recognition Device is now a days used more often and is preferred over Biometric Attendance inspite of being costly than traditional Biometric Attendance machines.</p>

				<p>Face Recognition Device is the next level where in place of fingerprints, scans of eye ratina and face is used.</p>

				<p>Face Recognition Device is little bit costly than the traditional Biometric Attendance but we at Sarojanil Technology Pvt. Ltd. try to provide it at a minimum possible rate, so that clients can used it more.</p>

				<p>We not only provide Face Recognition Device but also provide complete guidance to use it well and also provide best possible service in minimum possible time, so that work of our clients do not get hampered for long.</p>
				
			</div>
		</div>
		<?php include 'footer.php';?>