<?php $pageid=4;?>
<!DOCTYPE html>

<html lang="en">
<!-- Starting of head -->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>TIME ATTENDANCE RECORDER</title>
	    <meta name="Description" content="IT service provider in dhanbad" />
	    <meta name="Keywords" content="Dhanbad" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/style-index.css">
		
		<?php include 'header.php';?>
			<img src="images/biomatric.jpg" class="img-responsive" style="width: 100%;">
			<div class="container-fluid">
			<div style="padding: 5px;"></div>
			<div>
				<p>In this age of technology revolution, it is extremely important to get updated with technology to lessen the work overhead which was earlier done manually. It was not only time consuming but also not secure as anyone could have easliy mark attendance of others.</p>

				<p>Use of Biometric Time Attendance came as perfect solution which is not only saves time but is very much secure as well. Here attendance is marked with physical presence only as it is locked with bio signature in the form of fingerprints which is unique from person to person.</p>

				<p>A part from being secure and time saver, Biometric Time Attendance is also eco friendly as now we do not need papers to get result and everything is visible on screen. All the reports and statistics are done easily with some clicks only, which was used to consume much more time earlier.</p>

				<p>Sarojanil Technology Pvt. Ltd. feels proud to be one of the initiators to encourage use of Biometric Time Attendance in places where it make its presence felt.</p>
				
				<p>Different kind of Biometric machines suits different need of the clients and we provide perfect guidance to them to pick the best machine type suiting them.</p>
			</div>
		</div>
		<?php include 'footer.php';?>