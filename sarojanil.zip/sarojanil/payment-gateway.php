<?php $pageid=3;?>
<!DOCTYPE html>

<html lang="en">
<!-- Starting of head -->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>Payment Gateway</title>
	    <meta name="Description" content="IT service provider in dhanbad" />
	    <meta name="Keywords" content="Dhanbad" />
		<meta name="viewport" content="width=device-width">
		
		<link rel="stylesheet" href="css/style-index.css">
		
		<?php include 'header.php';?>
			<img src="images/payment-gateway.png" class="img-responsive" style="width: 100%;">
			<div class="container-fluid">
			<div style="padding: 5px;"></div>
			<div>
				<p>Ecommerce is boosting day by day in present scenario. Younger generation is moving towards online shopping because they love surfing rather moving out. This would be the right time to promote a business online.</p>
				<p>But keeping money transaction easy as well as secure is always a reason of concern for both the hosts and the customer using application.</p>
				<p>We, at Sarojanil Technology Pvt. Ltd., provide perfect solution to above mentioned problem. Providing correct payment gateway method that suits your business as well as customers using it is our speciality.</p>
				<b>Some highlights of Payment Gateway services:</b>
				<ul>
				  <li>Methods used for payment gateway is Easy and Convenient.</li>
				  <li>Provide full security features.</li>
				  <li>24 X 7 support is also provided.</li>
				  <li>Continuous updating with reports and other features updates are provided.</li>
				</ul>
			</div> 
			</div>
		<?php include 'footer.php';?>