<?php $pageid=4;?>
<!DOCTYPE html>

<html lang="en">
<!-- Starting of head -->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>CCTV</title>
	    <meta name="Description" content="IT service provider in dhanbad" />
	    <meta name="Keywords" content="Dhanbad" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/style-index.css">
		
		<?php include 'header.php';?>
			<img src="images/cctv.jpg" class="img-responsive" style="width: 100%;">
			<div class="container-fluid">
			<div style="padding: 5px;"></div>
			<div>
				<p>Today you cannot be so sure about safety of your family and belongings in your absence. Specially in the case related to old citizen, such crime rate have increased very much in past few years. CCTV is emerging as a solution to overcome your nighmares in such cases.</p>

				<p>Close Circuit TV, shortly called as CCTV gives you a comfort of watching over at what you value for. Coming at most reasonable rates with the fastest growing CCTV service provider named Sarojanil Technology Pvt. Ltd., we are able to provide customer satisfaction.</p>

				<p>Providing a way to access CCTV footage from far dsitance have added a must needed technology method in present context. All you need is an internet connection with static IP to access video footage from anywhere around the world.</p>
				
				<p>With the advancement of CCTV technology, now the customers are able to get relax far much more than earlier and Sarojanil Technology Pvt. Ltd. is proud to be one of the reason behind it.</p>

			</div>
		</div>
		<?php include 'footer.php';?>