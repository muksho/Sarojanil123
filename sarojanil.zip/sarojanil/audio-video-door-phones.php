<?php $pageid=4;?>
<!DOCTYPE html>

<html lang="en">
<!-- Starting of head -->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>AUDIO VIDEO DOOR PHONES</title>
	    <meta name="Description" content="IT service provider in dhanbad" />
	    <meta name="Keywords" content="Dhanbad" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/style-index.css">
		
		<?php include 'header.php';?>
			<img src="images/video-door-phone.jpg" class="img-responsive" style="width: 100%;">
			<div class="container-fluid">
			<div style="padding: 5px;"></div>
			<div>
				<p>Today everyone is concern about security of their loved ones. Althogh one is in office but he/she is always thinking and concern about their family at home. Crime rate with sernior citizens have also reached to new high in past few years.</p>

				<p>Audio Video Door Phones is coming very handy to overcome such issue. Weather single home or in apartment, Audio Video Door Phones are making their importance felt. With such facilities, now one need not to open the door directly. Instead, they can check the guest and only after getting satisfied, allow them to enter the house.</p>

				<p>Sarojanil Technology Pvt. Ltd. is one of the fastest growing Audio Video Door Phones providers, who provides them at cheap rate without compromising with quality and service.</p>
				
				<p>In Apartment culture, use of Audio Video Door Phones is a must need feature for the security of resident in that apartment. Now, any visitor can be verified at apartment gate only, that they have genuienly invited or are false personality.</p>

			</div>
		</div>
		<?php include 'footer.php';?>