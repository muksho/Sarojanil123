<?php $pageid=-1;?>
<!DOCTYPE html>

<html lang="en">
<!-- Starting of head -->
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title>Error 404</title>
	    <meta name="Description" content="IT service provider in dhanbad" />
	    <meta name="Keywords" content="Dhanbad" />
		<meta name="viewport" content="width=device-width">
		
		<link rel="stylesheet" href="css/style-index.css">
		
		<?php include 'header.php';?>
		<div style="padding: 55px;"></div>
			<div id="white" class="container" style="text-align: center;">
				<img src="images/danger.png" style="max-width: 200px; height: auto;"><br><br>
				<span style="font-size: 90px;">404 Error.</span>
						<div style="font-size: 30px;">
						Oops! We can't Find Anything at this location.
			  			</div>		
			</div>
			<div style="padding: 45px;"></div>
		<?php include 'footer.php';?>